import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Dashboard } from '@/hooks/queries/dashboards/dashboards.types';
import { cn } from '@/lib/utils';
import { Plus, RefreshCw, Save, Search, Settings } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';

export interface DashboardHeaderProps {
	dashboardName: string;
	onDashboardNameChange: (name: string) => void;
	onDashboardNameBlur: () => void;
	isDirty: boolean;
	onSave: () => void;
	onSettingsClick?: () => void;
	isRefreshing: boolean;
	lastRefresh?: Date;
	onRefresh: () => void;
	dashboards?: Dashboard[];
	onDashboardSelect?: (dashboard: Dashboard) => void;
	onNewDashboard?: () => void;
	isDraft?: boolean;
}

export const DashboardHeader = ({
	dashboardName,
	onDashboardNameChange,
	onDashboardNameBlur,
	isDirty,
	onSave,
	onSettingsClick,
	isRefreshing,
	lastRefresh,
	onRefresh,
	dashboards = [],
	onDashboardSelect,
	onNewDashboard,
	isDraft = false,
}: DashboardHeaderProps) => {
	const [isEditingName, setIsEditingName] = useState(false);
	const inputRef = useRef<HTMLInputElement>(null);
	const searchInputRef = useRef<HTMLInputElement>(null);
	const searchContainerRef = useRef<HTMLDivElement>(null);
	const [searchQuery, setSearchQuery] = useState('');
	const [isSearchFocused, setIsSearchFocused] = useState(false);
	const [activeIndex, setActiveIndex] = useState(-1);

	const filteredDashboards = useMemo(() => {
		return dashboards.filter(
			(d) => d.name !== dashboardName && d.name.toLowerCase().includes(searchQuery.toLowerCase())
		);
	}, [dashboards, dashboardName, searchQuery]);

	useEffect(() => {
		if (isEditingName && inputRef.current) {
			inputRef.current.focus();
			inputRef.current.select();
		}
	}, [isEditingName]);

	useEffect(() => {
		setActiveIndex(-1);
	}, [filteredDashboards]);

	useEffect(() => {
		if (!isSearchFocused) return;

		const handleClickAway = (e: MouseEvent) => {
			if (!searchContainerRef.current?.contains(e.target as Node)) {
				setIsSearchFocused(false);
				setActiveIndex(-1);
			}
		};

		document.addEventListener('mousedown', handleClickAway);

		return () => {
			document.removeEventListener('mousedown', handleClickAway);
		};
	}, [isSearchFocused]);

	const handleNameClick = () => {
		setIsEditingName(true);
	};

	const handleNameBlur = () => {
		setIsEditingName(false);
		onDashboardNameBlur();
	};

	const handleKeyDown = (e: React.KeyboardEvent) => {
		if (e.key === 'Enter') {
			handleNameBlur();
		}
	};

	const handleSearchKeyDown = (e: React.KeyboardEvent) => {
		if (!isSearchFocused || filteredDashboards.length === 0) return;

		if (e.key === 'ArrowDown') {
			e.preventDefault();
			setActiveIndex((index) => (index + 1) % filteredDashboards.length);
		}

		if (e.key === 'ArrowUp') {
			e.preventDefault();
			setActiveIndex((index) => (index <= 0 ? filteredDashboards.length - 1 : index - 1));
		}
		if (e.key === 'Enter' && activeIndex >= 0) {
			e.preventDefault();

			const dashboard = filteredDashboards[activeIndex];

			if (dashboard) {
				onDashboardSelect?.(dashboard);
				setSearchQuery('');
				setIsSearchFocused(false);
				setActiveIndex(-1);
			}
		}
		if (e.key === 'Escape') {
			e.preventDefault();
			setIsSearchFocused(false);
			setActiveIndex(-1);
		}
	};

	return (
		<div className="flex items-center gap-2">
			{/* Dashboard name + settings + save */}
			<div className="flex items-center gap-2 min-w-0 shrink">
				{isEditingName ? (
					<Input
						ref={inputRef}
						value={dashboardName}
						onChange={(e) => onDashboardNameChange(e.target.value)}
						onBlur={handleNameBlur}
						onKeyDown={handleKeyDown}
						className="text-xl font-bold h-9 w-auto min-w-[150px] max-w-[300px]"
					/>
				) : (
					<div className="flex items-center gap-2 min-w-0">
						<div
							onClick={handleNameClick}
							className="text-xl font-bold tracking-tight text-foreground cursor-pointer border border-transparent hover:border-input rounded px-2 py-1 -ml-2 transition-colors truncate"
							title={dashboardName || 'New Dashboard'}
						>
							{dashboardName || 'New Dashboard'}
						</div>
						{isDraft && (
							<span className="text-[10px] text-muted-foreground border border-muted-foreground/40 rounded px-1.5 py-0.5 leading-none shrink-0">
								Draft
							</span>
						)}
					</div>
				)}

				{onSettingsClick && (
					<Button
						variant="ghost"
						size="icon"
						onClick={onSettingsClick}
						title="Dashboard Settings"
						className="rounded-full h-8 w-8 hover:bg-muted hover:text-foreground shrink-0"
					>
						<Settings className="h-4 w-4" />
					</Button>
				)}

				{isDirty && (
					<Button
						variant="ghost"
						size="icon"
						onClick={onSave}
						title="Save Dashboard"
						className="rounded-full h-8 w-8 hover:bg-muted shrink-0"
					>
						<Save className="h-4 w-4 text-foreground" />
					</Button>
				)}
			</div>

			{/* Search (grows to fill the row) */}
			<div
				ref={searchContainerRef}
				className="relative flex-1 min-w-0"
				onBlur={(e) => {
					if (!searchContainerRef.current?.contains(e.relatedTarget as Node | null)) {
						setIsSearchFocused(false);
						setActiveIndex(-1);
					}
				}}
			>
				<div className="flex items-center h-8 rounded-md border bg-background px-3 focus-within:ring-1 focus-within:ring-ring">
					<Search className="mr-2 h-4 w-4 shrink-0 opacity-50 text-foreground" />
					<input
						ref={searchInputRef}
						className="flex h-full w-full bg-transparent text-sm text-foreground outline-hidden placeholder:text-muted-foreground"
						placeholder="Search dashboards..."
						role="combobox"
						aria-expanded={isSearchFocused && filteredDashboards.length > 0}
						aria-controls="dashboard-search-results"
						aria-activedescendant={
							activeIndex >= 0 ? `dashboard-option-${filteredDashboards[activeIndex]?.id}` : undefined
						}
						value={searchQuery}
						onChange={(e) => {
							setSearchQuery(e.target.value);
							setActiveIndex(-1);
						}}
						onFocus={() => setIsSearchFocused(true)}
						onKeyDown={handleSearchKeyDown}
					/>
				</div>
				{isSearchFocused && filteredDashboards.length > 0 && (
					<div className="absolute left-0 top-10 z-50 w-full max-w-64 rounded-lg border shadow-md bg-popover overflow-hidden">
						<ul className="max-h-[300px] overflow-y-auto py-1" id="dashboard-search-results" role="listbox">
							{filteredDashboards.map((dashboard, index) => (
								<li
									key={dashboard.id}
									id={`dashboard-option-${dashboard.id}`}
									role="option"
									aria-selected={index === activeIndex}
									className={cn(
										'px-2 py-1.5 text-sm text-popover-foreground cursor-pointer rounded-sm mx-1',
										index === activeIndex
											? 'bg-accent text-accent-foreground'
											: 'hover:bg-accent hover:text-accent-foreground'
									)}
									onMouseDown={(e) => {
										e.preventDefault();
										onDashboardSelect?.(dashboard);
										setSearchQuery('');
										setIsSearchFocused(false);
										searchInputRef.current?.blur();
									}}
								>
									{dashboard.name}
								</li>
							))}
						</ul>
					</div>
				)}
			</div>

			{/* Actions (fixed, right-aligned) */}
			<div className="flex items-center gap-2 shrink-0">
				<Button
					variant="ghost"
					size="icon"
					onClick={onRefresh}
					disabled={isRefreshing}
					className="rounded-full h-8 w-8 hover:bg-muted hover:text-foreground"
					title="Refresh"
				>
					<RefreshCw className={cn('h-4 w-4', isRefreshing && 'animate-spin')} />
				</Button>

				{onNewDashboard && (
					<Button size="sm" onClick={onNewDashboard} className="gap-2">
						<Plus className="h-4 w-4" />
						<span className="hidden sm:inline">New Dashboard</span>
					</Button>
				)}
			</div>
		</div>
	);
};
