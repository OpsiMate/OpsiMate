import { TableCell } from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { Alert } from '@OpsiMate/shared';
import { CopyCellButton } from '../../CopyCellButton';

export interface AlertNameColumnProps {
	alert: Alert;
	// Wrap the full name onto new lines instead of truncating (the "expand rows" toggle).
	expanded?: boolean;
	className?: string;
	// Inline width for content-aware sizing; wins over any width class.
	style?: React.CSSProperties;
}

export const AlertNameColumn = ({ alert, expanded = false, className, style }: AlertNameColumnProps) => {
	return (
		<TableCell style={style} className={cn('relative group/cell py-1 px-2 overflow-hidden', className)}>
			<span
				className={cn(
					'text-sm block text-foreground',
					expanded ? 'whitespace-normal wrap-break-word line-clamp-6' : 'truncate',
					// Unread alerts: render the name at the heaviest weight so it clearly
					// outweighs the read rows (font-medium). Requires the real 900 face
					// (loaded in main.tsx) — without it the browser clamps to 700.
					alert.isRead === false ? 'font-black' : 'font-medium'
				)}
				title={expanded ? undefined : alert.alertName}
			>
				{alert.alertName}
			</span>
			<CopyCellButton value={alert.alertName} />
		</TableCell>
	);
};
