import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { COLUMN_LABELS } from '../AlertsTable.constants';
import { FlatGroupItem, GroupStatus } from '../AlertsTable.types';

interface GroupHeaderProps {
	item: FlatGroupItem;
	onToggle: (key: string) => void;
	columnLabels?: Record<string, string>;
}

const getStatusBadgeVariant = (status: GroupStatus): 'destructive' | 'success' | 'muted' | 'secondary' => {
	switch (status) {
		case 'firing':
			return 'destructive';
		case 'muted':
			return 'secondary';
		case 'resolved':
			return 'success';
		case 'silenced':
			return 'muted';
	}
};

export const GroupHeader = ({ item, onToggle, columnLabels = {} }: GroupHeaderProps) => {
	if (item.type !== 'group') return null;

	const fieldLabel = columnLabels[item.field] || COLUMN_LABELS[item.field] || item.field;
	const badgeVariant = getStatusBadgeVariant(item.groupStatus);
	const mutedBadgeClass =
		item.groupStatus === 'muted' ? 'bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30' : '';

	return (
		<div
			className="flex items-center h-8 border-b bg-muted/50 hover:bg-muted/70 px-2 cursor-pointer"
			style={{ paddingLeft: `${item.level * 24 + 8}px` }}
			onClick={() => onToggle(item.key)}
		>
			<Button
				variant="ghost"
				size="icon"
				className="h-6 w-6 p-0 mr-2 text-foreground hover:bg-muted hover:text-foreground"
			>
				{item.isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
			</Button>
			{/* Fixed-width count right after the chevron so the numbers align vertically
			    across groups regardless of how long each group's label is. */}
			<Badge
				variant={badgeVariant}
				className={`h-5 min-w-10 justify-center px-1.5 mr-2 text-xs rounded-sm ${mutedBadgeClass}`}
			>
				{item.count}
			</Badge>
			<span className="font-semibold text-sm mr-2 text-foreground">{fieldLabel}:</span>
			<span className="text-sm text-foreground/80">{item.value}</span>
		</div>
	);
};
