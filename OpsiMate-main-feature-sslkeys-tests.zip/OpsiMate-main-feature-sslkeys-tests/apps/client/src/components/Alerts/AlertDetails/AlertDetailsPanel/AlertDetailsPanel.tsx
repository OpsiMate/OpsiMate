import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent } from '@/components/ui/tabs';
import { Alert } from '@OpsiMate/shared';
import { useEffect, useState } from 'react';
import { TimeRange } from '../../AlertsTable/TimeFilter/TimeFilter.types';
import { AlertDetailsBody } from '../AlertDetailsBody';
import { AlertDetailsHeader } from '../AlertDetailsHeader';
import { AlertFooterActions } from '../AlertFooterActions';
import { SectionsExpandContext, SectionsExpandControls, useSectionsExpandBroadcast } from '../CollapsibleSection';
import { CommentsWall } from '../CommentsWall';
import { useAlertHistory } from '../hooks';
import { PanelResizeHandle } from './PanelResizeHandle';
import { PanelTabsList } from './PanelTabsList';
import { useResizablePanelWidth } from './useResizablePanelWidth';

interface AlertDetailsPanelProps {
	alert: Alert;
	isActive: boolean;
	onClose: () => void;
	// Active time-range filter (the "All time" button), used to filter the History timeline.
	timeRange?: TimeRange | null;
	onSilence?: (alertId: string) => void;
	onUnsilence?: (alertId: string) => void;
	onDelete?: (alertId: string) => void;
	onUnresolve?: (alertId: string) => void;
}

export const AlertDetailsPanel = ({
	alert,
	isActive,
	onClose,
	timeRange,
	onSilence,
	onUnsilence,
	onDelete,
	onUnresolve,
}: AlertDetailsPanelProps) => {
	const historyData = useAlertHistory(alert.id);
	const [tab, setTab] = useState('details');
	const { width, panelRef, startResizing, resetWidth } = useResizablePanelWidth();
	const { signal, broadcast } = useSectionsExpandBroadcast();

	// Selecting a different alert starts a fresh read: back to Details, not whichever tab
	// the previous alert was left on. Reading someone else's comment thread is never what
	// clicking a new row means — and it also drops the half-typed comment that belonged to
	// the alert you just left (the wall unmounts with the tab).
	useEffect(() => {
		setTab('details');
	}, [alert.id]);

	return (
		<div
			ref={panelRef}
			style={{ width }}
			className="relative shrink-0 border-l bg-background flex flex-col h-full overflow-hidden"
		>
			<PanelResizeHandle onPointerDown={startResizing} onDoubleClick={resetWidth} />

			<AlertDetailsHeader
				onClose={onClose}
				className="px-4 py-3 shrink-0"
				actions={tab === 'details' && <SectionsExpandControls onBroadcast={broadcast} />}
			/>

			<Tabs value={tab} onValueChange={setTab} className="flex-1 flex flex-col min-h-0">
				<PanelTabsList />

				<TabsContent value="details" className="flex-1 min-h-0 mt-0">
					<ScrollArea className="h-full">
						<SectionsExpandContext.Provider value={signal}>
							<AlertDetailsBody
								alert={alert}
								historyData={historyData}
								timeRange={timeRange}
								onViewAllComments={() => setTab('comments')}
							/>
						</SectionsExpandContext.Provider>
					</ScrollArea>
				</TabsContent>

				<TabsContent value="comments" className="flex-1 min-h-0 mt-0">
					<CommentsWall alertId={alert.id} />
				</TabsContent>
			</Tabs>

			{/* Primary actions pinned at the panel's bottom, outside the scroll area. */}
			<div className="border-t p-3 shrink-0">
				<AlertFooterActions
					alert={alert}
					isActive={isActive}
					onSilence={onSilence}
					onUnsilence={onUnsilence}
					onDelete={onDelete}
					onUnresolve={onUnresolve}
				/>
			</div>
		</div>
	);
};
