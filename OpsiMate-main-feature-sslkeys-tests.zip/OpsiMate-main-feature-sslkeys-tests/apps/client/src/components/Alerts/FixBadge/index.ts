export { FixBadge } from './FixBadge';
