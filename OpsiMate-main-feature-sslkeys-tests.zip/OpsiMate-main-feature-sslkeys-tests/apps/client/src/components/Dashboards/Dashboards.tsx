import { DashboardLayout } from '@/components/DashboardLayout';
import { useDashboard } from '@/context/DashboardContext';
import { deserializeTimeRange } from '@/context/DashboardContext.utils';
import {
	useAddTagToDashboard,
	useDeleteDashboard,
	useGetAllDashboardTags,
	useGetDashboards,
	useRemoveTagFromDashboard,
} from '@/hooks/queries/dashboards';
import { Dashboard } from '@/hooks/queries/dashboards/dashboards.types';
import { useToast } from '@/hooks/use-toast';
import { Tag } from '@OpsiMate/shared';
import { useCallback, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { DashboardWithFavorite } from './Dashboards.types';
import { filterDashboards, getFavoriteDashboards, toggleFavorite } from './Dashboards.utils';
import { DashboardsFilter } from './DashboardsFilter';
import { DashboardsTable } from './DashboardsTable';

export const Dashboards = () => {
	const navigate = useNavigate();
	const location = useLocation();
	const { toast } = useToast();
	const { data: dashboards = [], isLoading } = useGetDashboards();
	const { data: dashboardTagsData = [] } = useGetAllDashboardTags();
	const deleteDashboardMutation = useDeleteDashboard();
	const addTagMutation = useAddTagToDashboard();
	const removeTagMutation = useRemoveTagFromDashboard();
	const { setInitialState, resetDashboard } = useDashboard();

	const [searchTerm, setSearchTerm] = useState('');
	const [selectedTagFilters, setSelectedTagFilters] = useState<number[]>([]);
	const [favorites, setFavorites] = useState<string[]>(() => getFavoriteDashboards());

	const dashboardTagsMap = useMemo(() => {
		const map: Record<string, Tag[]> = {};
		for (const item of dashboardTagsData) {
			map[String(item.dashboardId)] = item.tags;
		}
		return map;
	}, [dashboardTagsData]);

	const usedDashboardTags = useMemo(() => {
		const tagMap = new Map<number, Tag>();
		for (const item of dashboardTagsData) {
			for (const tag of item.tags) {
				if (!tagMap.has(tag.id)) {
					tagMap.set(tag.id, tag);
				}
			}
		}
		return Array.from(tagMap.values()).sort((a, b) => a.name.localeCompare(b.name));
	}, [dashboardTagsData]);

	const enrichedDashboards = useMemo<DashboardWithFavorite[]>(() => {
		return dashboards.map((d) => ({
			...d,
			isFavorite: favorites.includes(d.id),
			tags: dashboardTagsMap[d.id] || [],
		}));
	}, [dashboards, favorites, dashboardTagsMap]);

	const filteredDashboards = useMemo(() => {
		let result = filterDashboards(enrichedDashboards, searchTerm);

		if (selectedTagFilters.length > 0) {
			result = result.filter((d) => d.tags?.some((tag) => selectedTagFilters.includes(tag.id)));
		}

		return result;
	}, [enrichedDashboards, searchTerm, selectedTagFilters]);

	const handleTagFilterToggle = useCallback((tagId: number) => {
		setSelectedTagFilters((prev) => (prev.includes(tagId) ? prev.filter((id) => id !== tagId) : [...prev, tagId]));
	}, []);

	const clearTagFilters = useCallback(() => {
		setSelectedTagFilters([]);
	}, []);

	const handleDashboardClick = useCallback(
		(dashboard: Dashboard) => {
			// Mirrors Alerts.tsx's loader exactly. This used to omit timeRange (the first
			// time-range change then crashed DashboardProvider's isDirty memo on
			// serializeTimeRange(undefined) — a blank white page, since the provider sits
			// above the ErrorBoundary) and wiped columnOrder to [] — discarding the saved
			// arrangement whenever a dashboard was opened from this page.
			setInitialState({
				id: dashboard.id,
				name: dashboard.name,
				type: dashboard.type,
				description: dashboard.description || '',
				visibleColumns: dashboard.visibleColumns || [],
				filters: dashboard.filters || {},
				columnOrder: dashboard.columnOrder || [],
				groupBy: dashboard.groupBy || [],
				query: dashboard.query || '',
				timeRange: deserializeTimeRange(dashboard.timeRange),
			});
			navigate(`/alerts${location.search}`);
		},
		[navigate, setInitialState, location.search]
	);

	const handleDeleteDashboard = useCallback(
		async (dashboardId: string) => {
			try {
				await deleteDashboardMutation.mutateAsync(dashboardId);
				toast({
					title: 'Dashboard deleted',
					description: 'The dashboard has been successfully deleted.',
				});
			} catch (error) {
				const errorMessage = error instanceof Error ? error.message : 'Failed to delete dashboard';
				toast({
					title: 'Error',
					description: errorMessage,
					variant: 'destructive',
				});
			}
		},
		[deleteDashboardMutation, toast]
	);

	const handleToggleFavorite = useCallback((dashboardId: string) => {
		const newFavorites = toggleFavorite(dashboardId);
		setFavorites(newFavorites);
	}, []);

	const handleAddTag = useCallback(
		async (dashboardId: string, tag: Tag) => {
			try {
				await addTagMutation.mutateAsync({ dashboardId, tagId: tag.id });
			} catch (error) {
				const errorMessage = error instanceof Error ? error.message : 'Failed to add tag';
				toast({
					title: 'Error',
					description: errorMessage,
					variant: 'destructive',
				});
			}
		},
		[addTagMutation, toast]
	);

	const handleRemoveTag = useCallback(
		async (dashboardId: string, tagId: number) => {
			try {
				await removeTagMutation.mutateAsync({ dashboardId, tagId });
			} catch (error) {
				const errorMessage = error instanceof Error ? error.message : 'Failed to remove tag';
				toast({
					title: 'Error',
					description: errorMessage,
					variant: 'destructive',
				});
			}
		},
		[removeTagMutation, toast]
	);

	const handleCreateDashboard = useCallback(() => {
		resetDashboard();
		navigate(`/alerts${location.search}`);
	}, [navigate, resetDashboard, location.search]);

	return (
		<DashboardLayout>
			<div className="flex flex-col h-full p-6">
				<DashboardsFilter
					searchTerm={searchTerm}
					onSearchChange={setSearchTerm}
					availableTags={usedDashboardTags}
					selectedTagIds={selectedTagFilters}
					onTagToggle={handleTagFilterToggle}
					onClearTagFilters={clearTagFilters}
					onCreateDashboard={handleCreateDashboard}
				/>

				<DashboardsTable
					dashboards={filteredDashboards}
					isLoading={isLoading}
					onDashboardClick={handleDashboardClick}
					onDeleteDashboard={handleDeleteDashboard}
					onToggleFavorite={handleToggleFavorite}
					onCreateDashboard={handleCreateDashboard}
					onAddTag={handleAddTag}
					onRemoveTag={handleRemoveTag}
					availableTags={usedDashboardTags}
				/>
			</div>
		</DashboardLayout>
	);
};

export default Dashboards;
